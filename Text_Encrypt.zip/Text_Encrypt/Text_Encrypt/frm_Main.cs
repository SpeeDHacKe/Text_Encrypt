﻿using System;
using System.Web;
using System.Windows.Forms;
using WebPasswordEncryption;

namespace Text_Encrypt
{
    public partial class frm_Main : Form
    {
        enum EncryptType { Base64 = 1, PBKDF2 = 2, WebPassword = 3 }
        EncryptType encryptType;
       
        public frm_Main()
        {
            InitializeComponent();
        }

        private void rdo_Base64_CheckedChanged(object sender, EventArgs e)
        {
            encryptType = EncryptType.Base64;
            lbl_Encrypt.Text = "Base64 Encrypt :";
            lbl_Decrypt.Text = "Base64 Decrypt :";
        }

        private void rdo_PBKDF2_CheckedChanged(object sender, EventArgs e)
        {
            encryptType = EncryptType.PBKDF2;
            lbl_Encrypt.Text = "PBKDF2 Encrypt :";
            lbl_Decrypt.Text = "PBKDF2 Decrypt :";
        }

        private void rdo_WebPassword_CheckedChanged(object sender, EventArgs e)
        {
            encryptType = EncryptType.WebPassword;
            lbl_Encrypt.Text = "WebPassword Encrypt :";
            lbl_Decrypt.Text = "WebPassword Decrypt :";
        }

        private void btn_Encrypt_Click(object sender, EventArgs e)
        {
            string result = "";
            switch (encryptType)
            {
                case EncryptType.Base64:
                    encryptType = EncryptType.Base64;
                    result = txt_inputEncrypt.Text.Base64Encrypt();
                    break;
                case EncryptType.PBKDF2:
                    encryptType = EncryptType.PBKDF2;
                    result = txt_inputEncrypt.Text.PBKDF2Encrypt();
                    break;
                case EncryptType.WebPassword:
                    encryptType = EncryptType.WebPassword;
                    //result = txt_inputEncrypt.Text.WebPassEncrypt();
                    ClassPasswordEncryption encPassword = new ClassPasswordEncryption();
                    //result = HttpUtility.UrlEncode(encPassword.Encrypt_Password((string)txt_inputEncrypt.Text));
                    result = encPassword.Encrypt_Password((string)txt_inputEncrypt.Text);
                    break;
                default:
                    encryptType = EncryptType.Base64;
                    result = txt_inputEncrypt.Text.Base64Encrypt();
                    break;
            }

            txt_outputEncrypt.Text = result;
        }

        private void btn_Decrypt_Click(object sender, EventArgs e)
        {
            string result = "";
            switch (encryptType)
            {
                case EncryptType.Base64:
                    encryptType = EncryptType.Base64;
                    result = txt_inputDecrypt.Text.Base64Decrypt();
                    break;
                case EncryptType.PBKDF2:
                    encryptType = EncryptType.PBKDF2;
                    result = txt_inputDecrypt.Text.PBKDF2Decrypt();
                    break;
                case EncryptType.WebPassword:
                    encryptType = EncryptType.WebPassword;
                    ClassPasswordEncryption encPassword = new ClassPasswordEncryption();
                    //result = txt_inputDecrypt.Text.WebPassDecrypt();
                    result = HttpUtility.UrlDecode(encPassword.Decrypt_Password(txt_inputDecrypt.Text));
                    //result = encPassword.Decrypt_Password((string)txt_inputDecrypt.Text);
                    break;
                default:
                    encryptType = EncryptType.Base64;
                    result = txt_inputDecrypt.Text.Base64Decrypt();
                    break;
            }

            txt_outputDecrypt.Text = result;
        }
    }
}
